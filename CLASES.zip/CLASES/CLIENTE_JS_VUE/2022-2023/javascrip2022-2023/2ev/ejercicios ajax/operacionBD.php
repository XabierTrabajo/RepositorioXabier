<?php
// variables
$host = "localhost";
$username= "root";
$password = "";
$dbname = "facturaajax"
Allow: GET, POST, HEAD

try {

    $conexion = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // tomo el error y lo convierto en exception
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "conexion realizada";


}   
echo "<p>hola </p>";
catch (PDOException $e){
    echo "La conexión ha fallado: ". $e->getMessage();
}






?>