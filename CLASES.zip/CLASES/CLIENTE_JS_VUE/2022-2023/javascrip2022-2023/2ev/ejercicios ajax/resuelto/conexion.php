<?php

$dbserver = "localhost";
$dbuser = "root";
$password = "root";
$dbname = "facturaajax";


$con = new mysqli($dbserver, $dbuser, $password,$dbname);
if(!$con) {
    echo "No se pudo conectar a la base de datos";
  }

?>
