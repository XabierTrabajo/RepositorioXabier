
<?php
	//Opción 1 => Recibo los datos desde el FormData, y puedo acceder a ellos desde $_POST
		$cod=$_POST['cod'];
		if (!isset($_POST['cod'])){
			echo "No recibido codigo ";
		}
		else{
			include("conexion.php");
			if(!$con) {
				echo "No se pudo conectar a la base de datos";
			}

			$sql = "SELECT * FROM productos WHERE codigo = $cod";
			$result = $con->query($sql);
			$row=array();
			$row= $result->fetch_assoc();
			echo json_encode($row);
		}



	//Opción 2 => Si recibo los datos como un objeto desde Fetch
	
	/* $json = file_get_contents('php://input');//recibo todo
	$datos = json_decode($json, false);// lo decodifico de nuevo a objeto

	if(isset($datos->cod)) {//accedo al campo cod del objeto
		include("conexion.php");
		if(!$con) {
			echo "No se pudo conectar a la base de datos";
	  	}
		$cod=$datos->cod;//meto en la variable $cod el codigo del objeto
		$sql = "SELECT * FROM productos WHERE codigo = $cod";
		$result = $con->query($sql);
		$row=array();
		$row= $result->fetch_assoc();
		echo json_encode($row);
	  } */

	
		
?>

