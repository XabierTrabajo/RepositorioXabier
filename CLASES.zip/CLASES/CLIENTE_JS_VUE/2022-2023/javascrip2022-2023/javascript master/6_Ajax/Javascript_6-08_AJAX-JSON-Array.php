<?php
$a = array("Sara","Imanol","Dani","Antonio","David","Igor", "Naroa", "Christian", "Joseba", "Angel", "Alex", "Dumitru", "Mikel", "Ivan", "Martin");

$miJSON = json_encode($a);
echo $miJSON;

?>