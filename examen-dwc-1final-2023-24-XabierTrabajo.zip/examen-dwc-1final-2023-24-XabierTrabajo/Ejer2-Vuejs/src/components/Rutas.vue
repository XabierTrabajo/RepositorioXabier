<template>
    <nav>
        <RouterLink to="/">Home</RouterLink>
        | <RouterLink to="/about">About</RouterLink>
        <span v-show="logeado == false"> | <RouterLink to="/login">Login</RouterLink></span>
        <span v-show="logeado == true"> | <RouterLink to="/logout">Logout</RouterLink></span>
        <span v-show="logeado == true"> | <RouterLink to="/compras">Compras</RouterLink></span>
        <span v-show="logeado == true"> | <RouterLink to="/carrito">Carrito</RouterLink></span>
      </nav>
</template>
<script>
import { useCounter } from '../stores/counter';
import { mapState, mapActions } from 'pinia'

  export default {
      name: 'rutas',
      components: {},
      data(){
        return{}
      },
      methods:{
      },
      computed: {
        ...mapState(useCounter, ['logeado'])
      },
      mounted() {

      }
  }
</script>