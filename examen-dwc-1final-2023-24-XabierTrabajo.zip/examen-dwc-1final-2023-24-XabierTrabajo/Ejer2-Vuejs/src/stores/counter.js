
import { defineStore } from 'pinia'

export const useCounter = defineStore('store', {
  // state == data
  state: () => ({     
    usuario: [],
    productosComprados: [],
    logeado: false,
    total: 0
  }),
  // actions == methods
  actions: {
    guardarUsuario(user) {
      
      this.usuario.push(user);
      console.log("Guardado! El username es: "+this.usuario[0].username);
      //this.logeado = true;
    },

    guardarProducto(articulo) {
      
      // findIndex busca el producto en el carrito
      // si lo encuentra su valor es la posicion en el array pero si no lo encuentra devuelve -1
      const i = this.productosComprados.findIndex(element => element.title === articulo.title);

      // si ya esta le sumo una unidad
      if (i > -1) {
        console.log("Ese articulo ya está comprado! Añadiendo una nueva unidad...");
        this.productosComprados[i].units++;

        alert("El articulo "+ articulo.title +" ya ha sido comprado. Se añadirá una nueva unidad.");
      }
      
      // si no esta en el carrito lo añado
      else {
        console.log("Ese articulo ha sido comprado!");
        this.productosComprados.push(articulo);

        alert("El articulo "+ articulo.title +" ha sido comprado.");
      }

      this.total += articulo.price;
    },

    resetStore() {
      this.usuario = [];
      this.logeado = false;
      this.productosComprados = [];
      this.total = 0;
    },

    
  },
  // getters == computed
  getters: {
    calcularTotal() {
      for (let i = 0; i < this.productosComprados; i++) {
        this.total = this.total + (this.productosComprados[i].units * this.productosComprados[i].price); 
      }
      return this.total;
    }
  },
})
