<template>
    <div class="about">
      <h1>Examen 1FINAL DWC Curso 2023-24</h1><br>

      <span v-if="logeado == false"><h2>COMPRAS de ...</h2></span>
      <span v-if="logeado == true"><h2>COMPRAS de {{ this.usuario[0].username }}</h2></span>
    </div>

    <table>
      <tr>
          <th>Artículo</th>
          <th>Precio</th>
          <th>Unidades</th>
      </tr>
      <tr v-for="producto in productosComprados">
          
        <td>{{ producto.title }}</td>
        <td>{{ producto.price }}</td>
        <td>{{ producto.units }}</td>
      </tr>
      <tr>
        <td>TOTAL CARRITO</td>
        <td>{{ total }}</td>
      </tr>
    </table>
  </template>
  <script>
  
  
  import { useCounter } from '../stores/counter';
  import { mapState } from "pinia";
  export default{
    name: 'carrito',
    components: {
      
    },
    data() {
      return {
        
      }
    },
    methods:{
    
    },
    computed: {
    
      ...mapState(useCounter, ['usuario', 'logeado', 'productosComprados','total'])
    },
    created() {
      
    }
  }
  </script>