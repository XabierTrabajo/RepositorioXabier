<template>
    <div class="about">
      <h1>Examen 1FINAL DWC Curso 2023-24</h1><br>

      <span v-if="logeado == false"><h2>COMPRAS de ...</h2></span>
      <span v-if="logeado == true"><h2>COMPRAS de {{ this.usuario[0].username }}</h2></span>
    </div>

    <table style="text-align: left;">
    <tr>
        <th>Artículo</th>
        <th>Precio</th>
        <th>Unidades</th>
        <th>Subtotal</th>
    </tr>
    <tr v-for="producto in productosComprados">
      <!-- calculo el subtotal del producto con una variable local y luego lo paso a toFixed para evitar el bug del millon de decimales -->
      <td style="display: none;">{{ producto.subtotal = producto.price.toFixed(2) * producto.units.toFixed(2) }}</td>
      
      <td>{{ producto.title }}</td>
      <td style="text-align: center;">{{ producto.price }}</td>
      <td style="text-align: center;">{{ producto.units }}</td>
      <td style="text-align: center;">{{ producto.subtotal.toFixed(2) }}</td>
    </tr>
    <tr>
      <td>TOTAL CARRITO</td>
      <td>{{ total.toFixed(2) }}</td>
    </tr>
  </table>
  </template>
  <script>
  
  
  import { useCounter } from '../stores/counter';
  import { mapState } from "pinia";
  export default{
    name: 'carrito',
    components: {
      
    },
    data() {
      return {
        
      }
    },
    methods:{
    
    },
    computed: {
    
      ...mapState(useCounter, ['usuario', 'logeado', 'productosComprados','total'])
    },
    created() {
      
    }
  }
  </script>