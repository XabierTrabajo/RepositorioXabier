<template>
    <div>
      <table id="tabla">
        <tr>
          <th class="table">Artículo</th>
          <th class="table">Precio</th>
          <th class="table">Unidades</th>
        </tr>
        <tr v-for="producto in productosComprados">
          <td>{{ producto.title }}</td>
          <td style="text-align: center;">{{ producto.price }}€</td>
          <td style="text-align: center;">{{ producto.units }}</td>
        </tr>
      </table>
      <br><br><br>
      <h2>Total: {{ total.toFixed(2) }}€</h2>
      <h2>
        <span class="negativo" v-show="cambio < 0">Cambio: {{ cambio.toFixed(2) }}€</span>
        <span v-show="cambio > 0">Cambio: {{ cambio.toFixed(2) }}€</span>
      </h2>
      <form @submit="calcularCambio" @submit.prevent class="form">
        <span>Entregado: <input type="number" v-model="entregado">€</span>
        <button type="submit" style="margin-left: 3%;">Pagar</button>
      </form>
      
    </div>

</template>
<style>
  .negativo {
    color: red;
  }
  .form {
    font-size: larger;
    font-weight: bold;
  }
  #tabla, td, th {
    border: 1px solid black;
  }

  #tabla {
    border-collapse: collapse;
    width: 100%;
  }

  td {
    text-align: left;
  }
</style>
<script>
  import { useCounter } from '../stores/counter';
  import { mapState, mapActions } from "pinia";
  export default{
    name: 'CarritoView',
    components: {
      
    },
    data() {
      return {
        cambio: 0,
        entregado: 0
      }
    },
    methods:{
      calcularCambio() {
        this.cambio = this.entregado - this.total;
      }
    },
    computed: {
      
      ...mapState(useCounter, ['usuario', 'productosComprados', 'total'])
    },
    created() {
      
    }
  }
</script>