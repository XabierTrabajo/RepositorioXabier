<script>
import Inicio from '../components/Inicio.vue'
export default{
  name: 'HomeView',
  components: {
    Inicio
  }
}
</script>

<template>
  <main>
    <Inicio />
  </main>
</template>