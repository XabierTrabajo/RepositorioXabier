<template>
  <div class="about">
    <h1>Examen 1FINAL DWC Curso 2023-24</h1><br>
    
    <form @submit.prevent @submit="checkUsuarios">
      <h2>Datos de acceso</h2><br>
      <label for="username">Usuario</label>
      <input type="text" v-model="username"><br>
      <label for="password">Password</label>
      <input type="password" v-model="password">

      <br><br><br>
      <input id="login" type="submit" value="Login usuario">
    </form>
  </div>
</template>
<script>


import { useCounter } from '../stores/counter';
import { mapState, mapActions, mapWritableState } from 'pinia'
import axios from 'axios'
export default{
  name: 'login',
  components: {
    
  },
  data() {
    return {
      arrayUsuarios: [],
      username: "",
      password: "",
      intentos: 0
    }
  },
  methods:{
    async getUsuarios() {
      // obtiene mediante axios los datos de los usuarios
      const allData = await axios.get("/json/users.json");
      this.arrayUsuarios = allData.data;

      console.log(this.arrayUsuarios);
      // comprueba si ha iniciado sesion despues de cargar la pagina
      this.bloquearLoginBtn();
    },
    
    checkUsuarios() {
      // recorre el array de los usuarios buscando coincidencias
      for (let i = 0; i < this.arrayUsuarios.length; i++) {

        // si coinciden
        if (this.username == this.arrayUsuarios[i].username && this.password == this.arrayUsuarios[i].password) {
          console.log("Correcto!")
          alert("Usuario correcto. Bienvenido de nuevo "+this.username+".");

          this.logeado = true;
          this.bloquearLoginBtn();
          this.guardarUsuario(this.arrayUsuarios[i]);
          setTimeout(this.redirigir, 3000);
        }
        else {
          console.log("Intento incorrecto. Reintentando...")
          this.intentos++;
          
        }
        
      }

      // si al recorrer el array no encuentra credenciales correctas
      if (this.intentos == this.arrayUsuarios.length) {
        alert("Usuario o contraseña incorrectos")
        this.intentos = 0;
      }
    },

    redirigir () {
      this.$router.push('/');
    },

    // si ya esta logueado bloquea el btn
    bloquearLoginBtn() {
      if (this.logeado == true) {
        document.getElementById("login").setAttribute("disabled","");
      }
      else {
        document.getElementById("login").removeAttribute("disabled","");
      }
    },

    ...mapActions(useCounter,['guardarUsuario'])
  },
  computed: {
    

    ...mapState(useCounter, ['usuario']),
    ...mapWritableState(useCounter, ['logeado'])
  },
  created() {
    this.getUsuarios();
  }
}
</script>