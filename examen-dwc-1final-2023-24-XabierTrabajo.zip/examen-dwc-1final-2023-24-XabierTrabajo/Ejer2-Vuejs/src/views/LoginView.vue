<template>
    <div class="about">
      <h1>Examen 1FINAL DWC Curso 2023-24</h1><br>
      
      <form @submit.prevent @submit="checkUsuarios">
        <h2>Datos de acceso</h2><br>
        <label for="username">Usuario</label>
        <input type="text" name="username" id="username"><br>
        <label for="password">Password</label>
        <input type="password" name="password" id="password">

        <br><br><br>
        <input id="login" type="submit" value="Login usuario">
      </form>
    </div>
  </template>
  <script>
  
  
  import { useCounter } from '../stores/counter';
  import { mapState, mapActions } from 'pinia'
  import axios from 'axios'
  export default{
    name: 'login',
    components: {
      
    },
    data() {
      return {
        arrayUsuarios: [],
        username: "",
        password: "",
        intentos: 0
      }
    },
    methods:{
      async getUsuarios() {
        // obtiene mediante axios los datos de los usuarios
        const allData = await axios.get("/json/users.json");
        this.arrayUsuarios = allData.data;

        console.log(this.arrayUsuarios);
      },
      checkUsuarios() {
        this.username = document.getElementById("username").value;
        this.password = document.getElementById("password").value;

        // recorre el array de los usuarios buscando coincidencias
        for (let i = 0; i < this.arrayUsuarios.length; i++) {

          // si coinciden
          if (this.username == this.arrayUsuarios[i].username && this.password == this.arrayUsuarios[i].password) {
            console.log("Correcto!")
            alert("Usuario correcto. Bienvenido de nuevo "+this.username+".");
            
            this.guardarUsuario(this.arrayUsuarios[i]);
            document.getElementById("login").setAttribute("disabled","");
            this.$router.push('/');
          }
          else {
            console.log("Intento incorrecto. Reintentando...")
            this.intentos++;
            
          }
          
        }

        // si al recorrer el array no encuentra credenciales correctas
        if (this.intentos == this.arrayUsuarios.length) {
          alert("Usuario o contraseña incorrectos")
          this.intentos = 0;
        }
      },

      ...mapActions(useCounter,['guardarUsuario'])
    },
    computed: {
      ...mapState(useCounter, ['usuario'])
    },
    created() {
      this.getUsuarios();
    }
  }
  </script>