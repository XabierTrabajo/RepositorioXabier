<template>
    <div class="about">
      <h1>Examen 1FINAL DWC Curso 2023-24</h1><br>
      
      <div v-show="pulsado == false">
        <h2>Si has terminado con tu compra pulsa el botón para cerrar sesión.</h2><br>
        <button @click="click">Pulsa para cerrar sesión</button>
      </div>
      <h2 v-show="pulsado == true">Gracias por utilizar nuestra tienda, serás redirigido en breve a home</h2>
    </div>
  </template>
  <script>
  
  
  import { useCounter } from '../stores/counter';
  import { mapState, mapActions } from "pinia";
  export default{
    name: 'logout',
    components: {
      
    },
    data() {
      return {
        pulsado: false
      }
    },
    methods:{
      logout() {
        this.resetStore();
        this.$router.push('/');
      },

      click() {
        this.pulsado = true;
        setTimeout(this.logout, 3000);
      },

      ...mapActions(useCounter,['resetStore'])
    },
    computed: {
      ...mapState(useCounter, ['usuario','logeado'])
    },
    created() {
      
    }
  }
  </script>