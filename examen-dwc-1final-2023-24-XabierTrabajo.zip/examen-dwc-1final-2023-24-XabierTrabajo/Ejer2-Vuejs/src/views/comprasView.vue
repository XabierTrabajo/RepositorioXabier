<template>
  <div class="about">
    <h1>Examen 1FINAL DWC Curso 2023-24</h1><br>
    <span v-if="logeado == false"><h2>COMPRAS de ...</h2></span>
    <span v-if="logeado == true"><h2>COMPRAS de {{ this.usuario[0].username }}</h2></span>
   
    <div>
      <input type="checkbox" name="categoriaC" id="categoriaC" @click="categoriaBtn"><label for="categoriaC">Categorías</label>
      <input type="checkbox" name="precioC" id="precioC" @click="precioBtn"><label for="precioC">Precios</label>
      <br><br><br>
      <div id="cat" v-show="cat == true">
        <select name="categoria" id="categoria" v-model="busqueda">
          <option v-for="categoria in arrayCategorias" v-bind:value="categoria">{{ categoria }}</option>
        </select>
        <span>Categoría</span>
      </div>
      <div id="min" v-show="min == true">
        <input type="range" name="precio" id="precio" v-model="minimo" min="0" max="1000">
        <span>Mínimo seleccionado: {{minimo}}</span>
      </div>
      

    </div>
    <table>
    <tr>
        <th>Artículo</th>
        <th>Categoría</th>
        <th>Descripción</th>
        <th>Imagen</th>
        <th>Precio</th>
        <th>Comprar</th>
    </tr>
    <tr v-for="producto in filtros">
        
      <td>{{ producto.title }}</td>
      <td>{{ producto.category }}</td>
      <td>{{ producto.description }}</td>
      <td>
        <img :src="'' + producto.image" width="50" height="50" v-bind:alt="producto.image" > 
      </td>
      <td>{{ producto.price }}</td>
      <td><button @click="comprar(producto)">Comprar</button></td>
    </tr>


   </table>
  </div>
</template>
<script>
import axios from 'axios'

import { useCounter } from '../stores/counter';
import { mapState, mapActions } from "pinia";
export default{
  name: 'login',
  components: {
    
  },
  data() {
    return {
      arrayProductos: [],
      arrayCategorias: [],
      minimo: 0,
      busqueda:"",
      cat: false,
      min: false
    }
  },
  methods:{
    async getProductos() {
      // obtiene mediante axios los datos del juego
      const allData = await axios.get("/json/products.json");

      this.arrayProductos = allData.data;

      console.log(this.arrayProductos);
    },

    async getCategorias() {
      // obtiene mediante axios los datos del juego
      const allData = await axios.get("/json/categories.json");

      this.arrayCategorias = allData.data;

      console.log(this.arrayCategorias);
    },
    
    categoriaBtn() {
      this.cat = !this.cat;
    },

    precioBtn() {
      this.min = !this.min;
    },

    comprar(producto) {
      let articulo = {
        title: producto.title,
        price: producto.price,
        units: 1
      }

      this.guardarProducto(articulo);
    },

    ...mapActions(useCounter,['guardarProducto'])
  },
  computed: {
    
    filtros() {
      return this.arrayProductos.filter(
        (producto => {
          return producto.category.includes(this.busqueda) &&
          producto.price >= this.minimo;
        }));
    },

    ...mapState(useCounter, ['usuario', 'logeado'])
  },
  created() {
    this.getProductos();
    this.getCategorias();
  }
}
</script>

